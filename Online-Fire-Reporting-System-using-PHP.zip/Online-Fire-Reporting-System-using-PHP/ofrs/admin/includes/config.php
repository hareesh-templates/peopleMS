<?php
//database connection
$con=mysqli_connect("localhost","root","","ofrsdb");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
